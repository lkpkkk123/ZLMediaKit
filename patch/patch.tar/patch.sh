cp remote_info.txt ../.vscode/remote_info.txt
cp CMakeLists.txt ../api/CMakeLists.txt
cp CMakeLists_tests.txt ../api/tests/CMakeLists.txt 
cp macros.cpp ../src/Common/macros.cpp
